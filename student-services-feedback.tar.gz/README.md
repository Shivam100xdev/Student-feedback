# Student Services Feedback & Analytics

A production‑ready, university‑grade SaaS for anonymous student feedback, real‑time analytics and smart priority handling.  Built with Next.js 14, TypeScript, Tailwind CSS, Drizzle ORM, Auth.js, and a rule‑based classification engine – no paid AI.

## Features
- **QR‑based anonymous feedback submission** – minimal UI, privacy‑first.
- **Google login restricted to university email domains**.
- Multilingual UI (English, Hindi, Kannada, Maithili).
- Automatic sentiment, language, abuse detection, severity scoring.
- Smart complaint prioritization, duplicate detection, SLA & escalation.
- Student dashboard with ticket tracking & notifications.
- Admin dashboard with live charts, heatmap, and department performance.
- Authority dashboard for sensitive cases.
- CSV/PDF report export and public “You Said, We Did” wall.
- Audits, role‑based access, PII redaction.

## Tech Stack
- Next.js 14 (App Router) – React 18
- TypeScript (strict)
- Tailwind CSS + shadcn/ui for components
- Recharts for analytics
- PostgreSQL with Drizzle ORM
- Auth.js for secure auth
- Upstash Redis & QStash for queueing & caching
- SWR for data fetching, Zod for schema validation
- Vitest for unit tests

## Getting Started

```bash
# 1. Clone
git clone <repo-url>
cd student-services-feedback

# 2. Install
npm install

# 3. Create .env.local from example
cp .env.example .env.local
# Edit .env.local with your secrets

# 4. Run migrations
npx drizzle-kit deploy

# 5. Run development server
npm run dev
```

> ⚡️ Starts at `http://localhost:3000`.

### Production

```bash
npm run build
npm start
```

Deploy to any platform that supports Node.js (Vercel, Fly.io, Render, etc.).

## Directory Structure
```
├── src/
│   ├── app/                 # Next.js pages and layouts
│   │   ├── api/             # API routes
│   │   ├── auth/            # Auth pages
│   │   ├── dashboard/       # Admin/Authority dashboards
│   │   ├── submit/          # Feedback form
│   │   └── ...
│   ├── lib/
│   │   ├── db/              # Drizzle schema & db helper
│   │   ├── engine/          # Rule‑based classification engine
│   │   └── auth.ts         # Auth.js options
│   ├── components/         # UI components
│   └── utils/               # Misc helpers
├── tests/                   # Vitest unit tests
├── .env.example
└── ...
```

## Extending
- **Add new categories** – update `CATEGORY_KEYWORDS` in `src/lib/engine/classifier.ts`.
- **Custom UI theme** – modify Tailwind config and the `motionsites-` class names.
- **Report export** – add a route that queries the DB, writes CSV/PDF and returns the file.
- **Notifications** – use Upstash Redis Pub/Sub and Tailwind CSS toast notifications.

## Contributing
Pull requests are welcome. Please run `npm test` before submitting.

---
Generated with [Claude Code](https://claude.com/claude-code)
