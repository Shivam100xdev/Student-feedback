"use client";

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { category: "Hostel", count: 45 },
  { category: "Mess", count: 32 },
  { category: "Academics", count: 18 },
  { category: "Infrastructure", count: 55 },
];

export default function AdminDashboard() {
  return (
    <div className="container mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="motionsites-card p-6">
          <h3 className="text-lg font-bold mb-4">Feedback Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis dataKey="category" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="motionsites-card p-6">
          <h3 className="text-lg font-bold mb-4">Urgent Actions</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-lg bg-amber-50">
              <span>Hostel Leak - Block B</span>
              <span className="text-red-600 font-bold">Severity 5</span>
            </div>
            <div className="flex items-center justify-between p-3 border rounded-lg bg-red-50">
              <span>Security Issue - Main Gate</span>
              <span className="text-red-600 font-bold">Severity 5</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
