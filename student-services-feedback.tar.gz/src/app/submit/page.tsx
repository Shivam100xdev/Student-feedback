"use client";

import { useState } from "react";
import { analyzeComplaint } from "@/lib/engine/classifier";
import { Loader2 } from "lucide-react";

export default function SubmitFeedback() {
  const [text, setText] = useState("");
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = () => {
    setLoading(true);
    setTimeout(() => {
      setAnalysis(analyzeComplaint(text));
      setLoading(false);
    }, 600);
  };

  return (
    <div className="container mx-auto py-12 px-4 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8">Submit Feedback</h1>

      <div className="motionsites-card p-6 mb-8">
        <textarea
          className="w-full h-32 p-4 rounded-lg bg-secondary border focus:outline-none focus:ring-2 focus:ring-accent"
          placeholder="Share your concerns or feedback here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button
          onClick={handleAnalyze}
          className="mt-4 px-6 py-2 bg-primary text-white rounded-lg flex items-center gap-2"
          disabled={loading || !text}
        >
          {loading ? <Loader2 className="animate-spin" /> : "Analyze & Preview"}
        </button>
      </div>

      {analysis && (
        <div className="motionsites-card p-6 animate-in fade-in slide-in-from-bottom-4">
          <h3 className="text-lg font-bold mb-4">Preview Analysis</h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <p>Category: <strong>{analysis.category}</strong></p>
            <p>Severity: <strong>{analysis.severity}/5</strong></p>
            <p>Language: <strong>{analysis.language}</strong></p>
            <p>Sentiment: <strong>{analysis.sentiment}</strong></p>
          </div>
          <p className="mt-4 text-sm text-muted-foreground italic">
            {analysis.piiRedacted && "Note: PII was detected and automatically redacted."}
          </p>
          <button className="mt-6 w-full py-3 bg-accent text-white rounded-lg">Submit Feedback</button>
        </div>
      )}
    </div>
  );
}
