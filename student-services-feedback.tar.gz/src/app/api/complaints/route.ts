import { db } from "@/lib/db";
import { complaints } from "@/lib/db/schema";
import { analyzeComplaint, calculateSla } from "@/lib/engine/classifier";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { title, description, isAnonymous, studentId } = await req.json();

    // 1. Run Classification
    const analysis = analyzeComplaint(description);

    // 2. Prepare Database Entry
    const ticketCode = `FEED-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    const slaDeadline = calculateSla(analysis.severity);

    // 3. Persist
    await db.insert(complaints).values({
      ticketCode,
      title,
      description,
      redactedDescription: analysis.redactedText,
      category: analysis.category,
      severity: analysis.severity,
      sentiment: analysis.sentiment,
      sentimentScore: analysis.sentimentScore,
      language: analysis.language,
      isAnonymous: !!isAnonymous,
      studentId: isAnonymous ? null : studentId,
      slaDeadline,
      abuseFlagged: analysis.abuseFlagged,
      piiRedacted: analysis.piiRedacted,
    });

    return NextResponse.json({ ticketCode, status: "SUBMITTED" });
  } catch (error) {
    return NextResponse.json({ error: "Failed to submit feedback" }, { status: 500 });
  }
}
