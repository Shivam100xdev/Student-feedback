import Link from "next/link";
import { MessageSquare, BarChart3, ShieldAlert } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <nav className="border-b p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-tight">University Feedback</h1>
        <Link href="/auth/signin" className="px-4 py-2 bg-primary text-primary-foreground rounded-lg">Sign In</Link>
      </nav>

      <section className="container mx-auto py-20 text-center">
        <h2 className="text-5xl font-extrabold tracking-tighter mb-6">Student Services Feedback & Analytics</h2>
        <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">Anonymous, secure, and smart feedback platform for better campus life.</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
          <Link href="/submit" className="motionsites-card p-8 text-left">
            <MessageSquare className="w-10 h-10 mb-4 text-accent" />
            <h3 className="text-xl font-bold mb-2">Submit Feedback</h3>
            <p className="text-muted-foreground">Anonymous, classified, and prioritized automatically.</p>
          </Link>

          <Link href="/track" className="motionsites-card p-8 text-left">
            <ShieldAlert className="w-10 h-10 mb-4 text-amber-500" />
            <h3 className="text-xl font-bold mb-2">Track Tickets</h3>
            <p className="text-muted-foreground">Check status of your reported issues using your ticket code.</p>
          </Link>

          <Link href="/dashboard" className="motionsites-card p-8 text-left">
            <BarChart3 className="w-10 h-10 mb-4 text-indigo-500" />
            <h3 className="text-xl font-bold mb-2">View Analytics</h3>
            <p className="text-muted-foreground">Real-time campus issue trends and department performance.</p>
          </Link>
        </div>
      </section>
    </main>
  );
}
