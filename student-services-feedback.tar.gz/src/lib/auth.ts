import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || "mock-id",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "mock-secret",
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "google") {
        // Restricted to college domain (e.g., @university.edu or @mit.edu)
        const allowedDomain = process.env.ALLOWED_DOMAIN || "university.edu";
        return !!user.email?.endsWith(`@${allowedDomain}`) || user.email === "admin@example.com";
      }
      return true;
    },
    async session({ session, token }) {
      if (session.user) {
        // Mocking roles based on email for this demo
        if (session.user.email === "admin@university.edu" || session.user.email === "admin@example.com") {
          (session.user as any).role = "ADMIN";
        } else if (session.user.email?.includes("authority")) {
          (session.user as any).role = "AUTHORITY";
        } else {
          (session.user as any).role = "STUDENT";
        }
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
};
