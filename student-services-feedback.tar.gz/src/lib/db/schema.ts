import {
  pgTable,
  text,
  timestamp,
  integer,
  boolean,
  uuid,
  varchar,
  jsonb,
  doublePrecision
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name"),
  email: text("email").notNull().unique(),
  role: varchar("role", { length: 20 }).default("STUDENT").notNull(), // STUDENT, ADMIN, AUTHORITY
  department: text("department"),
  collegeId: text("college_id"),
  image: text("image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const complaints = pgTable("complaints", {
  id: uuid("id").primaryKey().defaultRandom(),
  ticketCode: varchar("ticket_code", { length: 20 }).notNull().unique(), // e.g. FEED-XXXX
  title: text("title").notNull(),
  description: text("description").notNull(),
  redactedDescription: text("redacted_description"),
  category: varchar("category", { length: 50 }).notNull(), // HOSTEL, MESS, ACADEMICS, etc.
  severity: integer("severity").default(1).notNull(), // 1-5
  sentiment: varchar("sentiment", { length: 20 }).default("NEUTRAL").notNull(),
  sentimentScore: doublePrecision("sentiment_score").default(0),
  language: varchar("language", { length: 10 }).default("EN").notNull(),
  status: varchar("status", { length: 20 }).default("SUBMITTED").notNull(), // SUBMITTED, UNDER_REVIEW, IN_PROGRESS, RESOLVED, REJECTED, ESCALATED
  isAnonymous: boolean("is_anonymous").default(false).notNull(),
  studentId: uuid("student_id").references(() => users.id),
  anonymousToken: text("anonymous_token"), // used for tracking without login
  locationBuilding: text("location_building"),
  locationDetail: text("location_detail"),
  piiRedacted: boolean("pii_redacted").default(false),
  abuseFlagged: boolean("abuse_flagged").default(false),
  assignedDept: text("assigned_dept"),
  slaDeadline: timestamp("sla_deadline"),
  escalatedToRole: varchar("escalated_to_role", { length: 20 }),
  upvotes: integer("upvotes").default(0).notNull(),
  resolutionNote: text("resolution_note"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  complaintId: uuid("complaint_id").references(() => complaints.id),
  actorId: uuid("actor_id").references(() => users.id),
  action: text("action").notNull(), // STATUS_CHANGE, ASSIGNED, ESCALATED, etc.
  details: jsonb("details"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: varchar("type", { length: 20 }).notNull(), // STATUS_UPDATE, ASSIGNMENT, ESCALATION
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const publicResolutions = pgTable("public_resolutions", {
  id: uuid("id").primaryKey().defaultRandom(),
  complaintId: uuid("complaint_id").references(() => complaints.id),
  title: text("title").notNull(),
  issue: text("issue").notNull(),
  resolution: text("resolution").notNull(),
  category: text("category").notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});
